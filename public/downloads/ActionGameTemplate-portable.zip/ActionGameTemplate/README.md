# STYLISH ACTION — 鬼泣式动作游戏模板 + Demo

一个**零依赖、纯静态**的 2D 横版动作游戏模板。双击 `index.html` 即可在浏览器直接游玩。

战斗流程参考《**鬼泣 / Devil May Cry**》：清版波次 → 精英压制 → Boss 三阶段决战；
招式与技能设计参考《**地狱潜兵 / Helldivers**》（方向码支援律令）、《**血咒之城 / Code Vein**》
（血技、无敌帧构装、影缝位移）、《**传说系列 / Tales of**》系列（多段极技与秘奥义演出）。

## 游玩方式

> 直接双击 `index.html`（无构建、无依赖、file:// 下可运行）。

### 操作

| 按键 | 功能 |
|---|---|
| `←/→` 或 `A/D` | 移动 |
| `空格` | 跳跃（可二段跳） |
| `J` | 轻击连段（连按接招 / 空中浮空追打） |
| `K` | 重击（大伤害 + 击退） |
| `L` | 挑空（把敌人打上天 → 空中连段） |
| `Shift` | 翻滚（0.3s 无敌帧，可取消技能硬直） |
| `U / I` | 角色技能 1 / 2（各自冷却） |
| `Q` | **支援律令**：按下后按角色指定的方向码（如 `▶▶◀`）完成呼叫，输错/超时律令中断 |
| `O` | 奥义（计量满 100 时释放，参考秘奥义演出：慢镜头 + 无敌） |
| `Esc` | 暂停 / 撤退 · `M` 节拍音效开关 |

### 关卡流程（5 波）

1. **血港潮涌** — 疾魔犬 × 浮火小鬼（热身刷风格评级）
2. **邪念增援** — 腐肉巨人 + 邪教法师远程火力
3. **精英来袭 · 圣殿看守** — 霸体精英，循环出招〔盾冲→圣锤砸地→回旋横扫〕
4. **双重威胁** — 双精英（圣殿看守 + 尖啸使）+ 杂兵
5. **BOSS · 灰烬僭主摩迪凯** — 三阶段：
   - P1：双连斩 / 魔弹 / 突斩
   - P2（60%）：+大地崩裂、召唤杂兵
   - P3（25%）：+灰烬逆位（瞬移背后）、焚天陨雨，节奏大幅加快

### 风格评级系统（DMC 核心）

造成伤害/技能命中都会积累风格值，**同招重复命中收益递减**、超时衰减、**受击直接腰斩并清连段**。
`D → C → B → A → S → SS → SSS`，评级越高收益手感越强（右上角大字实时显示）。

---

## 模板结构（内聚分层，改内容不碰逻辑）

```
D:\ActionGameTemplate\
├─ index.html            入口（脚本加载即插即用）
├─ core\
│  ├─ engine.js          引擎底座：常量/输入/合成音效(Fx)粒子系统
│  ├─ entities.js        战斗实体：Hitbox/弹幕/冲击环/光柱/火区 + 玩家状态机 + 敌人AI + Boss阶段机
│  └─ game.js            流程与HUD：场景(标题/选人/战斗/结算)、波次脚本、风格评级、律令输入、判定解算
├─ data\
│  ├─ characters.js      10 名可操作角色（连段/技能/律令/奥义 全在此表）
│  └─ enemies.js         小怪×4 · 精英×2 · Boss×1 + WAVES 波次脚本
└─ README.md
```

### 上市公司如何加一个新角色（唯一需要动的文件：`data/characters.js`）

```js
{
  id: 'myhero', name: '新角色·名字', weap: 'katana', glyph: '★',
  col: { c1:'#232333', c2:'#7fd4ff', c3:'#bffcf0', hair:'#ffffff' },
  hp: 110, spd: 330, quip: '台词。',
  combo:   [ M({...}), M({...}), M({...}), M({...}) ],  // J 连段 4 步
  heavy:   M({ dur:.5, box:[-170,190,-100,0], dmg:21, kx:380 }),   // K
  launcher:M({ box:[-70,90,-190,10], dmg:12, ky:-680, launch:true }), // L 挑空
  skills: [ {key:'s1', name, icon, cd, cast(P){ G.proj({...} or G.hitRel(...) } }, ... ],
  strat: { name:'支援律令：XX', code:['R','R','D'], cd:17, cast(P){...} },
  ult:  { name:'奥义·XX', cast(P){ G.slowmo(...); G.hitRel(...) } },
}
```
放进 `CHARS` 数组即可 —— 选人界面、面板、HUD 全部自动出现。

### 加一个新敌人 / 新波次（`data/enemies.js`）

- 杂兵：往 `MOBS` 加一条（`shape` 选 `hound/imp/robe/brute` 之一，或自己在 entities.js 加新绘制分支）；
- 精英：往 `ELITES` 加一条，用 `seq:['a','b','c']` 指定循环出招顺序，`armorF` 越小越霸体；
- 波次：往 `WAVES` 追加 `{name, sub, spawns:[['runner', 延迟, x 位置], ...]}`。

技能层可用 API（在 `core/game.js` 实现于 Game 类）：
`G.hitRel / G.hitAbs / G.proj / G.shock / G.beam / G.meteors / G.fire / G.orb / G.spawn / G.delayed / G.slowmo / G.shake / G.banner`

### 数值调参快速入口

- 全局手感：`core/engine.js` 的 `CONFIG`（重力/浮空倍率/边界）
- 风格评级阈值：`core/game.js` 顶部 `RANKS`
- 命中顿帧/硬直：`core/game.js` `_applyHit`、`core/entities.js` `takeHit`
- 敌人 AI 节奏：`data/enemies.js` 各条目的 `atkCd / tele / rec`

## 设计映射表（参考来源 → 模板机制）

| 来源参考 | 模板机制 |
|---|---|
| 鬼泣 · 连段与浮空 | J 连段缓冲接招、L 挑空 + 空中追打、风格评级 D~SSS |
| 鬼泣 · 风格 STYLISH | 重复招式收益递减、受击掉级 |
| 地狱潜兵 · 战备呼叫 | Q + 方向码支援律令（输错中断、冷却惩罚），轨道炮/空袭/弹幕 |
| 血咒之城 · 血技 | 无敌构装、影缝位移、血潮吸血 |
| 传说系列 · 极技/秘奥义 | 多段位移技能 + 奥义（慢镜头演出 + 无敌帧） |

祝狩猎愉快。
