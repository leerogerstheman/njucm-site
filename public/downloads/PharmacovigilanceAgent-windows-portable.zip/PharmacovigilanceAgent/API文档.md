# 药智·药物警戒助手 - API 接口文档

> **统一的双层 API 架构** - 既支持浏览器内调用，也支持 HTTP RESTful 访问

本项目实现了基于 hello-agents 框架的双层 API 接口，方便前端调用与扩展集成。

## 架构概览

```
┌─────────────────────────────────────────────┐
│         用户界面 (Material Design 3)        │
├─────────────────────────────────────────────┤
│   前端 API 层 (api.js) - PVApi 类          │
│   ├── categories  - 分类管理                │
│   ├── documents   - 文档管理                │
│   ├── query       - 智能问答                │
│   ├── naranjo     - 因果关系评价            │
│   ├── interactions - 相互作用查询           │
│   ├── meddra      - MedDRA术语速查           │
│   ├── cases       - 经典案例                │
│   ├── stats       - 知识库统计              │
│   └── tools       - 通用工具                │
├─────────────────────────────────────────────┤
│   后端 API 层 (backend_api.py) - 可选       │
│   └── Flask REST API 服务                    │
└─────────────────────────────────────────────┘
```

## 一、前端 API 接口（api.js）

`api.js` 提供 `PVApi` 类，是浏览器内的统一接口层。所有方法都返回 Promise/值，可在前端代码中直接调用。

### 1. 分类管理 `api.categories`

```javascript
// 列出所有分类
const cats = api.categories.list();
// → [{ id, name, name_en, icon, document_count }, ...]

// 获取特定分类详情
const cat = api.categories.get('basic_concepts');
// → { id, name, documents: [...] }

// 获取分类摘要（带文档预览）
const summary = api.categories.summary('case_studies');
```

### 2. 文档管理 `api.documents`

```javascript
// 获取特定文档
const doc = api.documents.get('concept_adr');

// 关键词搜索文档
const results = api.documents.search('肝毒性', 5);

// 列出所有文档
const allDocs = api.documents.list();
```

### 3. 智能问答 `api.query`

```javascript
// RAG 风格问答
const result = await api.query.ask('什么是Naranjo评分？');
// → { query, response, intent, timestamp, sources }

// 简化版 - 仅返回响应
const response = api.query.simple('肝毒性有哪些药物？');

// 仅识别意图
const intent = api.query.intent('什么是华法林');
```

### 4. Naranjo 评分 `api.naranjo`

```javascript
// 获取问题列表
const questions = api.naranjo.questions();

// 计算评分
const result = api.naranjo.calculate({
  q1: 'yes',  // 是
  q2: 'yes',  // 否
  q3: 'yes',  // 不详
  ...
});
// → { score, answered, total, complete, category, description }
```

### 5. 相互作用查询 `api.interactions`

```javascript
// 列出所有已知相互作用
const pairs = api.interactions.list();

// 检查两种药物
const result = api.interactions.check('华法林', '阿司匹林');
// → { found, drug_a, drug_b, severity, mechanism, consequence, management }

// 按严重程度筛选
const majorOnes = api.interactions.filterBySeverity('严重');
```

### 6. MedDRA 速查 `api.meddra`

```javascript
// 获取所有 MedDRA 分类
const categories = api.meddra.categories();

// 获取特定分类的术语
const terms = api.meddra.terms('皮肤系统');

// 搜索 MedDRA 术语
const results = api.meddra.search('皮疹');
// → [{ category, terms: [{ cn, en }] }]
```

### 7. 经典案例 `api.cases`

```javascript
// 列出所有案例
const cases = api.cases.list();

// 获取特定案例
const thalidomide = api.cases.get('case_thalidomide');
```

### 8. 知识库统计 `api.stats`

```javascript
// 获取知识库摘要
const stats = api.stats.summary();
// → {
//   version, name, last_updated,
//   categories_count, documents_count,
//   interactions_count, cases_count
// }

// 获取分类统计
const catStats = api.stats.categoryStats();
```

### 9. 通用工具 `api.tools`

```javascript
// 随机推荐问题
const suggestions = api.tools.suggestedQueries(4);

// 关键词提取
const keywords = api.tools.extractKeywords('肝毒性有哪些表现？');
```

## 二、后端 HTTP API 接口（backend_api.py）

为高级用户提供本地 HTTP RESTful API 服务。

### 启动方法

```bash
cd D:\PharmacovigilanceAgent
python src\backend_api.py
```

服务启动后自动打开浏览器访问 `http://127.0.0.1:5000/`。

### API 端点

| 方法 | 端点 | 功能 |
|------|------|------|
| GET | `/api/health` | 健康检查 |
| GET | `/api/version` | 获取版本信息 |
| GET | `/api/categories` | 列出所有分类 |
| GET | `/api/categories/<id>` | 获取特定分类 |
| GET | `/api/documents` | 列出所有文档 |
| GET | `/api/documents/<id>` | 获取特定文档 |
| GET | `/api/search?q=<keyword>` | 关键词搜索 |
| POST | `/api/query` | 智能问答 |
| POST | `/api/naranjo/calculate` | Naranjo 评分计算 |
| GET | `/api/interactions` | 列出所有相互作用 |
| POST | `/api/interactions/check` | 药物相互作用查询 |
| GET | `/api/meddra/categories` | MedDRA 分类 |
| GET | `/api/meddra/search?q=<term>` | MedDRA 搜索 |
| GET | `/api/cases` | 列出经典案例 |
| GET | `/api/stats` | 知识库统计 |

### 使用示例

**1. 健康检查**
```bash
curl http://127.0.0.1:5000/api/health
```
响应：
```json
{"service":"PV Agent API","status":"ok"}
```

**2. 智能问答**
```bash
curl -X POST http://127.0.0.1:5000/api/query \
  -H "Content-Type: application/json" \
  -d '{"query":"什么是药物警戒？"}'
```
响应：
```json
{
  "query": "什么是药物警戒？",
  "response": "## 什么是药物警戒\n\n...",
  "sources": [{"id": "concept_pv", "title": "...", "category": "..."}],
  "timestamp": 1696345678901
}
```

**3. Naranjo 评分**
```bash
curl -X POST http://127.0.0.1:5000/api/naranjo/calculate \
  -H "Content-Type: application/json" \
  -d '{"answers":{"q1":"yes","q2":"yes","q3":"yes","q4":"no","q5":"no","q6":"no","q7":"yes","q8":"yes","q9":"yes","q10":"yes"}}'
```
响应：
```json
{
  "score": 10,
  "answered": 10,
  "total": 10,
  "category": "肯定（Certain）",
  "description": "药物与不良反应之间的因果关系明确"
}
```

**4. 相互作用查询**
```bash
curl -X POST http://127.0.0.1:5000/api/interactions/check \
  -H "Content-Type: application/json" \
  -d '{"drugA":"华法林","drugB":"阿司匹林"}'
```
响应：
```json
{
  "found": true,
  "drug_a": "华法林",
  "drug_b": "阿司匹林",
  "severity": "严重",
  "mechanism": "联合抗凝作用",
  "consequence": "出血风险显著增加",
  "management": "避免联用，必要时加强INR监测"
}
```

**5. 搜索**
```bash
curl "http://127.0.0.1:5000/api/search?q=肝毒性"
```
响应：
```json
[
  {
    "id": "organ_liver",
    "title": "肝毒性（药物性肝损伤）",
    "category": "organ_systems",
    "score": 9,
    "preview": "..."
  }
]
```

## 三、前端访问后端 API

如需前端使用后端 HTTP API（而非浏览器内 JS API），可以修改 `app.js`：

```javascript
// 使用后端 API
const response = await fetch('http://localhost:5000/api/query', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ query: '什么是药物警戒？' })
});
const data = await response.json();
console.log(data.response);
```

## 四、扩展开发

### 添加新的 API 端点

1. 在 `api.js` 的 `PVApi` 类中添加方法
2. 如需后端支持，在 `backend_api.py` 中添加 `@app.route`
4. 保持接口命名一致

### 自定义 Agent 行为

修改 `app.js` 中的 `PharmacovigilanceAgent` 类，或在 `api.js` 中添加新的工具。

## 五、版本兼容

| API 版本 | 知识库版本 | 说明 |
|----------|------------|------|
| 2.0 | 2.0.x | 双层 API、扩展知识库 |
| 1.0 | 1.0.x | 单层 JS API |

---

**注意**：后端 API 仅供高级用户使用，前端应用无需后端即可独立运行（使用浏览器内 JS API）。