@echo off
chcp 65001 >nul
title 药智·药物警戒助手
color 0B

REM 药智·药物警戒助手 - 主启动器
REM 双击此文件即可启动程序（无需安装任何依赖）

echo.
echo ╔════════════════════════════════════════════╗
echo ║     药智 · 药物警戒助手                      ║
echo ║     Pharmacovigilance Assistant             ║
echo ║                                              ║
echo ║     面向药学学生的智能体                     ║
echo ║     基于 Datawhale hello-agents 框架          ║
echo ╚════════════════════════════════════════════╝
echo.

REM 获取脚本所在目录
set "SCRIPT_DIR=%~dp0"
cd /d "%SCRIPT_DIR%"

REM 检查主文件是否存在
if not exist "index.html" (
    echo [错误] 找不到 index.html 主程序文件！
    echo 请确认您运行的是完整的项目文件夹。
    pause
    exit /b 1
)

echo [信息] 正在启动浏览器...
echo [提示] 如果浏览器没有自动打开，请手动打开 index.html
echo.

REM 等待 1 秒后启动浏览器
timeout /t 1 /nobreak >nul

REM 优先尝试使用 Edge 或 Chrome 打开，无痕模式（避免缓存问题）
start "" "msedge.exe" "file:///%SCRIPT_DIR%index.html" 2>nul
if %errorlevel% neq 0 (
    start "" "chrome.exe" "file:///%SCRIPT_DIR%index.html" 2>nul
)
if %errorlevel% neq 0 (
    REM 使用系统默认浏览器
    start "" "file:///%SCRIPT_DIR%index.html"
)

echo [信息] 启动完成！浏览器窗口已打开。
echo.
echo ╔════════════════════════════════════════════╗
echo ║ 使用提示：                                   ║
echo ║  • 在左侧选择知识主题浏览                     ║
echo ║  • 在下方输入框提问                           ║
echo ║  • 点击"工具"按钮使用辅助功能                ║
echo ║                                              ║║
echo ║ 关闭浏览器窗口即可退出程序                    ║
echo ╚════════════════════════════════════════════╝
echo.
echo [说明] 本程序为完全离线运行，所有数据存储在本地。
echo [说明] 如有问题，请查看项目中的 README.md 文档。
echo.
echo 按任意键关闭此窗口...
pause >nul