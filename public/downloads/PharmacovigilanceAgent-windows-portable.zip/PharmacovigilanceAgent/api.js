/* ================================================
   药智·药物警戒助手 - API 接口层
   提供统一的、模块化的 API 访问入口
   基于 hello-agents 框架的 ReAct / RAG 范式
   ================================================ */

/**
 * API 类 - 模拟 REST 接口的资源组织
 * 设计参考: hexagram/hello-agents 的工具接口层
 */
class PVApi {
  constructor(kb) {
    this.kb = kb;
    this.version = kb.version || '1.0.0';
    this.agent = new PharmacovigilanceAgent(kb);
    this.cache = new Map();
    this.callHistory = [];
    this.observers = {};
  }

  /* ================================================
     分类 (Categories) API
     ================================================ */
  get categories() {
    return {
      /**
       * 列出所有分类
       * GET /api/categories
       */
      list: () => {
        return this.kb.categories.map(cat => ({
          id: cat.id,
          name: cat.name,
          name_en: cat.name_en,
          icon: cat.icon,
          document_count: cat.documents.length,
        }));
      },

      /**
       * 获取特定分类详情
       * GET /api/categories/:id
       */
      get: (id) => {
        const cat = this.kb.categories.find(c => c.id === id);
        if (!cat) return null;
        return {
          id: cat.id,
          name: cat.name,
          name_en: cat.name_en,
          icon: cat.icon,
          documents: cat.documents.map(d => ({
            id: d.id,
            title: d.title,
            title_en: d.title_en,
            keywords: d.keywords,
          })),
        };
      },

      /**
       * 获取分类摘要（含每个文档简介）
       */
      summary: (id) => {
        const cat = this.kb.categories.find(c => c.id === id);
        if (!cat) return null;
        return {
          ...this.categories.get(id),
          documents: cat.documents.map(d => ({
            id: d.id,
            title: d.title,
            preview: d.content.substring(0, 100) + '...',
            keywords: d.keywords,
          })),
        };
      },
    };
  }

  /* ================================================
     文档 (Documents) API
     ================================================ */
  get documents() {
    return {
      /**
       * 获取特定文档
       * GET /api/documents/:id
       */
      get: (id) => {
        for (const cat of this.kb.categories) {
          const doc = cat.documents.find(d => d.id === id);
          if (doc) return { ...doc, category: cat.id, category_name: cat.name };
        }
        return null;
      },

      /**
       * 关键词搜索文档
       * GET /api/documents/search?q=keyword
       */
      search: (query, limit = 10) => {
        if (!query || !query.trim()) return [];
        const q = query.toLowerCase().trim();
        const results = [];

        for (const cat of this.kb.categories) {
          for (const doc of cat.documents) {
            let score = 0;

            // 标题完全匹配
            if (doc.title.toLowerCase().includes(q)) score += 10;
            if (doc.title_en && doc.title_en.toLowerCase().includes(q)) score += 5;

            // 关键词匹配
            if (doc.keywords) {
              for (const kw of doc.keywords) {
                if (q.includes(kw.toLowerCase()) || kw.toLowerCase().includes(q)) {
                  score += 3;
                }
              }
            }

            // 内容匹配
            const content = doc.content.toLowerCase();
            const tokens = q.split(/\s+/);
            for (const token of tokens) {
              if (token.length >= 2 && content.includes(token)) {
                score += 1;
              }
            }

            if (score > 0) {
              results.push({
                id: doc.id,
                title: doc.title,
                category: cat.id,
                category_name: cat.name,
                score,
                preview: doc.content.substring(0, 200),
              });
            }
          }
        }

        results.sort((a, b) => b.score - a.score);
        return results.slice(0, limit);
      },

      /**
       * 获取所有文档的扁平列表
       */
      list: () => {
        const docs = [];
        for (const cat of this.kb.categories) {
          for (const doc of cat.documents) {
            docs.push({
              id: doc.id,
              title: doc.title,
              title_en: doc.title_en,
              category: cat.id,
              category_name: cat.name,
              keywords: doc.keywords,
            });
          }
        }
        return docs;
      },
    };
  }

  /* ================================================
     查询 (Query) API - 智能问答
     ================================================ */
  get query() {
    return {
      /**
       * 处理用户查询 - ReAct 风格的 RAG
       * POST /api/query
       * Body: { query: string }
       */
      ask: (query, options = {}) => {
        const result = this.agent.processQuery(query);
        return {
          query,
          response: result,
          intent: this._detectIntent(query),
          timestamp: Date.now(),
          sources: this.documents.search(query, 3),
        };
      },

      /**
       * 简化问答 - 仅返回响应内容
       */
      simple: (query) => {
        return this.agent.processQuery(query);
      },

      /**
       * 意图识别
       */
      intent: (query) => this._detectIntent(query),

      /**
       * 智能搜索 - 返回结构化结果
       */
      search: (query, limit = 5) => {
        return this.documents.search(query, limit);
      },
    };
  }

  /**
   * 内部：意图识别
   */
  _detectIntent(query) {
    const q = query.toLowerCase().trim();

    if (/^(你好|hi|hello|您好|嗨)/i.test(q)) {
      return { type: 'greeting', confidence: 1.0 };
    }

    if (/naranjo|评分|因果关系评价/.test(q)) {
      return { type: 'tool_naranjo', confidence: 0.9 };
    }

    if (/相互作用|配伍|联合用药/.test(q)) {
      return { type: 'tool_interaction', confidence: 0.9 };
    }

    if (/meddra|编码/.test(q)) {
      return { type: 'tool_meddra', confidence: 0.9 };
    }

    // 分类匹配
    for (const cat of this.kb.categories) {
      if (q.includes(cat.name.toLowerCase()) || q.includes(cat.name_en.toLowerCase())) {
        return { type: 'category', category: cat.id, confidence: 0.7 };
      }
    }

    return { type: 'general', confidence: 0.5 };
  }

  /* ================================================
     Naranjo 因果关系评价 API
     ================================================ */
  get naranjo() {
    return {
      /**
       * 获取问题列表
       * GET /api/naranjo/questions
       */
      questions: () => {
        return this.kb.tools.naranjo_calculator.questions;
      },

      /**
       * 计算评分
       * POST /api/naranjo/calculate
       * Body: { answers: { q1: 'yes', q2: 'no', ... } }
       */
      calculate: (answers) => {
        const questions = this.kb.tools.naranjo_calculator.questions;
        let score = 0;
        let answered = 0;

        questions.forEach(q => {
          const value = answers[q.id];
          if (value) {
            score += q[value] || 0;
            answered++;
          }
        });

        let category, description;
        if (score >= 9) {
          category = '肯定（Certain）';
          description = '药物与不良反应之间的因果关系明确';
        } else if (score >= 5) {
          category = '很可能（Probable）';
          description = '药物与不良反应之间很可能存在因果关系';
        } else if (score >= 1) {
          category = '可能（Possible）';
          description = '药物与不良反应之间可能存在因果关系';
        } else {
          category = '可疑（Doubtful）';
          description = '药物与不良反应之间的因果关系不明确';
        }

        return {
          score,
          answered,
          total: questions.length,
          complete: answered === questions.length,
          category,
          description,
          answers,
        };
      },
    };
  }

  /* ================================================
     药物相互作用 API
     ================================================ */
  get interactions() {
    return {
      /**
       * 列出所有已知相互作用
       * GET /api/interactions
       */
      list: () => {
        return this.kb.tools.interaction_pairs;
      },

      /**
       * 检查两种药物的相互作用
       * POST /api/interactions/check
       * Body: { drugA: string, drugB: string }
       */
      check: (drugA, drugB) => {
        if (!drugA || !drugB) {
          return { found: false, error: '请提供两种药物名称' };
        }

        const a = drugA.trim().toLowerCase();
        const b = drugB.trim().toLowerCase();

        // 双向匹配
        const match = this.kb.tools.interaction_pairs.find(p =>
          ((p.drug_a.toLowerCase().includes(a) || a.includes(p.drug_a.toLowerCase())) &&
           (p.drug_b.toLowerCase().includes(b) || b.includes(p.drug_b.toLowerCase()))) ||
          ((p.drug_a.toLowerCase().includes(b) || b.includes(p.drug_a.toLowerCase())) &&
           (p.drug_b.toLowerCase().includes(a) || a.includes(p.drug_b.toLowerCase())))
        );

        if (match) {
          return {
            found: true,
            drug_a: match.drug_a,
            drug_b: match.drug_b,
            severity: match.severity,
            mechanism: match.mechanism,
            consequence: match.consequence,
            management: match.management,
          };
        }

        return {
          found: false,
          drugA,
          drugB,
          message: '知识库中未找到该药物组合的相互作用数据，建议查阅 Lexicmicomp、Micromedex 等专业资源。',
        };
      },

      /**
       * 按严重程度筛选
       */
      filterBySeverity: (severity) => {
        return this.kb.tools.interaction_pairs.filter(p => p.severity === severity);
      },
    };
  }

  /* ================================================
     MedDRA 速查 API
     ================================================ */
  get meddra() {
    return {
      /**
       * 列出所有 MedDRA 分类
       */
      categories: () => {
        const data = this._getMedDRAData();
        return Object.keys(data);
      },

      /**
       * 获取特定分类下的术语
       */
      terms: (categoryName) => {
        const data = this._getMedDRAData();
        return data[categoryName] || [];
      },

      /**
       * 搜索 MedDRA 术语
       */
      search: (query) => {
        if (!query || !query.trim()) return [];

        const q = query.toLowerCase().trim();
        const data = this._getMedDRAData();
        const results = [];

        for (const [catName, items] of Object.entries(data)) {
          const filtered = items.filter(it =>
            it.cn.toLowerCase().includes(q) ||
            it.en.toLowerCase().includes(q)
          );
          if (filtered.length > 0) {
            results.push({
              category: catName,
              terms: filtered,
            });
          }
        }

        return results;
      },

      /**
       * 获取所有数据
       */
      all: () => this._getMedDRAData(),

      /**
       * 内部：从知识库提取 MedDRA 数据
       */
      _getMedDRAData: () => this._getMedDRAData(),
    };
  }

  _getMedDRAData() {
    if (this._meddraCache) return this._meddraCache;

    const docId = 'tool_meddra_search';
    for (const cat of this.kb.categories) {
      for (const doc of cat.documents) {
        if (doc.id === docId) {
          this._meddraCache = this._parseMedDRAContent(doc.content);
          return this._meddraCache;
        }
      }
    }
    return {};
  }

  _parseMedDRAContent(content) {
    const categories = {};
    const sections = content.split(/【(.+?)】/).slice(1);

    for (let i = 0; i < sections.length; i += 2) {
      const catName = sections[i];
      const catContent = sections[i + 1];
      const items = [];
      const lines = catContent.split('\n').filter(l => l.trim().startsWith('-'));

      lines.forEach(line => {
        const match = line.match(/-\s*(.+?)\s*\((.+?)\)/);
        if (match) {
          items.push({ cn: match[1].trim(), en: match[2].trim() });
        }
      });

      if (items.length > 0) {
        categories[catName] = items;
      }
    }

    return categories;
  }

  /* ================================================
     经典案例 API
     ================================================ */
  get cases() {
    return {
      /**
       * 列出所有经典案例
       */
      list: () => {
        const cat = this.kb.categories.find(c => c.id === 'case_studies');
        if (!cat) return [];
        return cat.documents.map(d => ({
          id: d.id,
          title: d.title,
          title_en: d.title_en,
          preview: d.content.substring(0, 150) + '...',
          keywords: d.keywords,
        }));
      },

      /**
       * 获取特定案例详情
       */
      get: (id) => {
        return this.documents.get(id);
      },
    };
  }

  /* ================================================
     统计 (Stats) API
     ================================================ */
  get stats() {
    return {
      /**
       * 知识库摘要
       */
      summary: () => {
        const docs = this.documents.list();
        const interactions = this.interactions.list();
        const cases = this.cases.list();

        return {
          version: this.version,
          name: this.kb.name,
          last_updated: this.kb.last_updated,
          categories_count: this.kb.categories.length,
          documents_count: docs.length,
          interactions_count: interactions.length,
          cases_count: cases.length,
          meddra_categories_count: this.meddra.categories().length,
        };
      },

      /**
       * 获取分类统计
       */
      categoryStats: () => {
        return this.kb.categories.map(cat => ({
          id: cat.id,
          name: cat.name,
          documents: cat.documents.length,
          total_keywords: cat.documents.reduce((sum, d) => sum + (d.keywords?.length || 0), 0),
        }));
      },
    };
  }

  /* ================================================
     工具 (Tools) API - 通用工具
     ================================================ */
  get tools() {
    return {
      /**
       * 随机推荐问题
       */
      suggestedQueries: (count = 4) => {
        const suggestions = [
          '什么是药物警戒？',
          'Naranjo评分如何使用？',
          'MedDRA编码有哪些常用术语？',
          '如何报告ADR？',
          '肝毒性常见于哪些药物？',
          '妊娠期用药有哪些注意事项？',
          '华法林有哪些配伍禁忌？',
          '什么是药物相互作用？',
          '介绍一下反应停事件',
          '什么是PSUR？',
          'GVP什么时候开始实施？',
          '什么是药物基因组学？',
        ];

        // 随机选择
        const shuffled = [...suggestions].sort(() => 0.5 - Math.random());
        return shuffled.slice(0, count);
      },

      /**
       * 关键词提取
       */
      extractKeywords: (text) => {
        const stopWords = new Set(['的', '是', '在', '和', '与', '或', '了', '有', '如何', '什么', '怎么', '为', '对', '可以']);
        const tokens = text.replace(/[^\w\s\u4e00-\u9fff]/g, ' ').split(/\s+/);
        return [...new Set(tokens.filter(t => t.length >= 2 && !stopWords.has(t.toLowerCase())))];
      },
    };
  }

  /* ================================================
     调用追踪
     ================================================ */
  trackCall(method, args) {
    this.callHistory.push({
      method,
      args,
      timestamp: Date.now(),
    });
    // 仅保留最近 100 条
    if (this.callHistory.length > 100) {
      this.callHistory = this.callHistory.slice(-100);
    }
  }

  /**
   * 获取调用历史
   */
  getCallHistory() {
    return [...this.callHistory];
  }

  /**
   * 清空缓存
   */
  clearCache() {
    this.cache.clear();
    this._meddraCache = null;
  }
}

/* ================================================
   全局 API 实例
   ================================================ */
window.PVApi = PVApi;