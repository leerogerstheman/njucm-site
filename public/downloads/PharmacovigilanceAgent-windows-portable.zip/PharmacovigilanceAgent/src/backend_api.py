"""
药智·药物警戒助手 - 后端 HTTP API 服务
============================================

基于 Flask 的 REST API 服务，提供知识库查询、Naranjo评分、相互作用查询等
功能。该服务独立运行在 localhost:5000，前端可以通过 HTTP 调用。

启动方法：
    python backend_api.py

API 端点：
    GET  /api/health                    - 健康检查
    GET  /api/version                   - API版本
    GET  /api/categories                - 获取所有分类
    GET  /api/categories/<id>           - 获取特定分类
    GET  /api/documents                 - 列出所有文档
    GET  /api/documents/<id>            - 获取特定文档
    GET  /api/search?q=keyword          - 搜索文档
    POST /api/query                     - 智能问答
    POST /api/naranjo/calculate         - Naranjo评分
    POST /api/interactions/check        - 相互作用查询
    GET  /api/interactions              - 列出所有相互作用
    GET  /api/meddra/categories         - MedDRA分类
    GET  /api/meddra/search?q=term      - MedDRA搜索
    GET  /api/cases                     - 经典案例
    GET  /api/stats                     - 知识库统计
"""

import os
import sys
import json
from pathlib import Path

# Flask 依赖检查
try:
    from flask import Flask, request, jsonify, send_from_directory
    from flask_cors import CORS
except ImportError:
    print("=" * 60)
    print("[错误] Flask 未安装")
    print("=" * 60)
    print("请运行以下命令安装：")
    print("  pip install flask flask-cors")
    print("=" * 60)
    sys.exit(1)

# 项目路径
PROJECT_ROOT = Path(__file__).parent.parent
KB_PATH = PROJECT_ROOT / "data" / "knowledge_base.json"

# 加载知识库
def load_kb():
    with open(KB_PATH, "r", encoding="utf-8") as f:
        return json.load(f)

KB = load_kb()

# 创建 Flask 应用
app = Flask(__name__, static_folder=str(PROJECT_ROOT), static_url_path="")
CORS(app)  # 允许跨域

# ================================================
# 健康检查 & 版本
# ================================================
@app.route("/api/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "service": "PV Agent API"})

@app.route("/api/version", methods=["GET"])
def version():
    return jsonify({
        "version": KB.get("version"),
        "name": KB.get("name"),
        "last_updated": KB.get("last_updated"),
    })

# ================================================
# 分类 API
# ================================================
@app.route("/api/categories", methods=["GET"])
def list_categories():
    return jsonify([
        {
            "id": c["id"],
            "name": c["name"],
            "name_en": c["name_en"],
            "icon": c["icon"],
            "document_count": len(c["documents"]),
        }
        for c in KB["categories"]
    ])

@app.route("/api/categories/<cat_id>", methods=["GET"])
def get_category(cat_id):
    cat = next((c for c in KB["categories"] if c["id"] == cat_id), None)
    if not cat:
        return jsonify({"error": "Category not found"}), 404
    return jsonify({
        "id": cat["id"],
        "name": cat["name"],
        "name_en": cat["name_en"],
        "icon": cat["icon"],
        "documents": [
            {"id": d["id"], "title": d["title"], "title_en": d["title_en"]}
            for d in cat["documents"]
        ],
    })

# ================================================
# 文档 API
# ================================================
def find_doc(doc_id):
    for cat in KB["categories"]:
        for doc in cat["documents"]:
            if doc["id"] == doc_id:
                return doc, cat
    return None, None

@app.route("/api/documents", methods=["GET"])
def list_documents():
    docs = []
    for cat in KB["categories"]:
        for doc in cat["documents"]:
            docs.append({
                "id": doc["id"],
                "title": doc["title"],
                "title_en": doc.get("title_en"),
                "category": cat["id"],
                "category_name": cat["name"],
                "keywords": doc.get("keywords", []),
            })
    return jsonify(docs)

@app.route("/api/documents/<doc_id>", methods=["GET"])
def get_document(doc_id):
    doc, cat = find_doc(doc_id)
    if not doc:
        return jsonify({"error": "Document not found"}), 404
    return jsonify({
        **doc,
        "category": cat["id"],
        "category_name": cat["name"],
    })

# ================================================
# 搜索 API
# ================================================
@app.route("/api/search", methods=["GET"])
def search():
    query = request.args.get("q", "").strip()
    if not query:
        return jsonify([])
    q = query.lower()
    results = []

    for cat in KB["categories"]:
        for doc in cat["documents"]:
            score = 0
            if query in doc["title"]:
                score += 10
            for kw in doc.get("keywords", []):
                if q in kw.lower():
                    score += 3
            content = doc["content"].lower()
            tokens = q.split()
            for t in tokens:
                if len(t) >= 2 and t in content:
                    score += 1
            if score > 0:
                results.append({
                    "id": doc["id"],
                    "title": doc["title"],
                    "category": cat["id"],
                    "category_name": cat["name"],
                    "score": score,
                    "preview": doc["content"][:200],
                })

    results.sort(key=lambda x: x["score"], reverse=True)
    return jsonify(results[:10])

# ================================================
# 查询 API
# ================================================
@app.route("/api/query", methods=["POST"])
def query():
    data = request.get_json()
    if not data or "query" not in data:
        return jsonify({"error": "Missing query"}), 400

    q = data["query"].strip()
    if not q:
        return jsonify({"error": "Empty query"}), 400

    # 简单的 RAG 检索
    results = search_with_score(q)

    # 构造响应
    response = ""
    if results:
        top_doc = results[0]
        doc_data = top_doc["doc"]
        response = f"## {doc_data['title']}\n\n"
        # 取前 500 字符
        content = doc_data["content"][:800]
        response += content
        if len(doc_data["content"]) > 800:
            response += "\n\n...（更多内容请使用文档ID获取）"
    else:
        response = KB["system_prompts"]["no_match_response"]

    return jsonify({
        "query": q,
        "response": response,
        "sources": [{"id": r["doc"]["id"], "title": r["doc"]["title"], "category": r["category"]} for r in results[:3]],
        "timestamp": int(__import__('time').time() * 1000),
    })

def search_with_score(query, min_score=2):
    q = query.lower()
    results = []
    for cat in KB["categories"]:
        for doc in cat["documents"]:
            score = 0
            if query in doc["title"]:
                score += 10
            for kw in doc.get("keywords", []):
                if q in kw.lower() or kw.lower() in q:
                    score += 3
            content = doc["content"].lower()
            tokens = q.split()
            for t in tokens:
                if len(t) >= 2 and t in content:
                    score += 1
            if score >= min_score:
                results.append({"doc": doc, "category": cat["id"], "score": score})
    results.sort(key=lambda x: x["score"], reverse=True)
    return results

# ================================================
# Naranjo API
# ================================================
@app.route("/api/naranjo/calculate", methods=["POST"])
def naranjo_calculate():
    data = request.get_json()
    if not data or "answers" not in data:
        return jsonify({"error": "Missing answers"}), 400

    answers = data["answers"]
    questions = KB["tools"]["naranjo_calculator"]["questions"]
    score = 0
    answered = 0

    for q in questions:
        value = answers.get(q["id"])
        if value:
            score += q.get(value, 0)
            answered += 1

    if score >= 9:
        category = "肯定（Certain）"
        description = "药物与不良反应之间的因果关系明确"
    elif score >= 5:
        category = "很可能（Probable）"
        description = "药物与不良反应之间很可能存在因果关系"
    elif score >= 1:
        category = "可能（Possible）"
        description = "药物与不良反应之间可能存在因果关系"
    else:
        category = "可疑（Doubtful）"
        description = "药物与不良反应之间的因果关系不明确"

    return jsonify({
        "score": score,
        "answered": answered,
        "total": len(questions),
        "category": category,
        "description": description,
    })

# ================================================
# 相互作用 API
# ================================================
@app.route("/api/interactions", methods=["GET"])
def list_interactions():
    return jsonify(KB["tools"]["interaction_pairs"])

@app.route("/api/interactions/check", methods=["POST"])
def check_interaction():
    data = request.get_json()
    if not data or "drugA" not in data or "drugB" not in data:
        return jsonify({"error": "Missing drug names"}), 400

    a = data["drugA"].strip().lower()
    b = data["drugB"].strip().lower()

    match = None
    for p in KB["tools"]["interaction_pairs"]:
        if (
            (a in p["drug_a"].lower() or p["drug_a"].lower() in a) and
            (b in p["drug_b"].lower() or p["drug_b"].lower() in b)
        ) or (
            (a in p["drug_b"].lower() or p["drug_b"].lower() in a) and
            (b in p["drug_a"].lower() or p["drug_a"].lower() in b)
        ):
            match = p
            break

    if match:
        return jsonify({
            "found": True,
            "drug_a": match["drug_a"],
            "drug_b": match["drug_b"],
            "severity": match["severity"],
            "mechanism": match["mechanism"],
            "consequence": match["consequence"],
            "management": match["management"],
        })
    return jsonify({
        "found": False,
        "drugA": data["drugA"],
        "drugB": data["drugB"],
        "message": "知识库中未找到该药物组合的相互作用数据",
    })

# ================================================
# MedDRA API
# ================================================
@app.route("/api/meddra/categories", methods=["GET"])
def meddra_categories():
    return jsonify([
        "皮肤系统", "消化系统", "血液系统", "神经系统",
        "心血管系统", "呼吸系统", "全身性反应",
    ])

@app.route("/api/meddra/search", methods=["GET"])
def search_meddra():
    query = request.args.get("q", "").strip()
    if not query:
        return jsonify([])
    return jsonify({"query": query, "results": []})  # 简化实现

# ================================================
# 案例 API
# ================================================
@app.route("/api/cases", methods=["GET"])
def list_cases():
    for cat in KB["categories"]:
        if cat["id"] == "case_studies":
            return jsonify([
                {"id": d["id"], "title": d["title"], "title_en": d.get("title_en")}
                for d in cat["documents"]
            ])
    return jsonify([])

# ================================================
# 统计 API
# ================================================
@app.route("/api/stats", methods=["GET"])
def stats():
    docs_count = sum(len(c["documents"]) for c in KB["categories"])
    return jsonify({
        "version": KB.get("version"),
        "name": KB.get("name"),
        "last_updated": KB.get("last_updated"),
        "categories_count": len(KB["categories"]),
        "documents_count": docs_count,
        "interactions_count": len(KB["tools"]["interaction_pairs"]),
    })

# ================================================
# 静态文件服务（HTML/CSS/JS）
# ================================================
@app.route("/")
def index():
    return send_from_directory(str(PROJECT_ROOT), "index.html")

@app.route("/<path:filename>")
def static_files(filename):
    return send_from_directory(str(PROJECT_ROOT), filename)

# ================================================
# 主函数
# ================================================
def main():
    import webbrowser
    import threading

    host = "127.0.0.1"
    port = 5000

    print("=" * 60)
    print("药智·药物警戒助手 - HTTP API 服务")
    print("=" * 60)
    print(f"知识库: {KB.get('name')}")
    print(f"版本: {KB.get('version')}")
    print(f"分类: {len(KB['categories'])}")
    print(f"文档: {sum(len(c['documents']) for c in KB['categories'])}")
    print("=" * 60)
    print(f"服务地址: http://{host}:{port}")
    print(f"浏览器访问: http://{host}:{port}/")
    print()
    print("可用API:")
    print("  GET  /api/health")
    print("  GET  /api/categories")
    print("  GET  /api/documents")
    print("  POST /api/query")
    print("  POST /api/naranjo/calculate")
    print("  POST /api/interactions/check")
    print("  GET  /api/stats")
    print("=" * 60)
    print("按 Ctrl+C 停止服务")
    print()

    # 自动打开浏览器
    def open_browser():
        import time
        time.sleep(1.5)
        webbrowser.open(f"http://{host}:{port}/")

    threading.Thread(target=open_browser, daemon=True).start()

    app.run(host=host, port=port, debug=False, use_reloader=False)


if __name__ == "__main__":
    main()