"""
药智·药物警戒助手 - 打包为单一 .exe 文件
==========================================

使用 PyInstaller 将整个项目打包为单一可执行文件（.exe），
无需用户安装任何依赖（Python、pip、SQL 等）。

使用方法：
    pip install pyinstaller
    python build_exe.py

生成位置：dist/药智·药物警戒助手.exe
"""

import os
import sys
import shutil
import subprocess
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent.parent
BUILD_DIR = PROJECT_ROOT / "build"
DIST_DIR = PROJECT_ROOT / "dist"


def main():
    print("=" * 60)
    print("药智·药物警戒助手 - 打包脚本")
    print("=" * 60)
    print()

    # 检查 PyInstaller
    try:
        import PyInstaller
        print(f"[OK] PyInstaller 已安装 (版本: {PyInstaller.__version__})")
    except ImportError:
        print("[INFO] PyInstaller 未安装，正在安装...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "pyinstaller"])
        print("[OK] PyInstaller 安装完成")

    # 清理旧的构建
    if BUILD_DIR.exists():
        shutil.rmtree(BUILD_DIR)
        print("[OK] 清理旧的 build 目录")
    if DIST_DIR.exists():
        shutil.rmtree(DIST_DIR)
        print("[OK] 清理旧的 dist 目录")

    # 准备必要的文件
    files_to_include = [
        ("index.html", "."),
        ("styles.css", "."),
        ("app.js", "."),
        ("data/knowledge_base.js", "data"),
        ("启动药物警戒助手.vbs", "."),
        ("README.md", "."),
    ]

    print()
    print("[INFO] 开始打包...")
    print()

    # 构建 PyInstaller 命令
    cmd = [
        sys.executable, "-m", "PyInstaller",
        "--noconfirm",
        "--clean",
        "--onefile",
        "--windowed",
        "--name=药智",  # .exe 名称（会自动加 .exe 后缀）
        "--add-data=index.html;.",
        "--add-data=styles.css;.",
        "--add-data=app.js;.",
        "--add-data=data/knowledge_base.js;data",
        "--add-data=启动药物警戒助手.vbs;.",
        "--add-data=README.md;.",
        # 图标（如果有）
        # "--icon=assets/icon.ico",
        # 创建一个启动器脚本
        "src/launcher.py",
    ]

    # 打印命令
    print("执行命令：")
    print(" ".join(cmd))
    print()

    # 执行打包
    try:
        subprocess.check_call(cmd)
        print()
        print("=" * 60)
        print("[OK] 打包完成！")
        print()
        print(f"[输出位置] {DIST_DIR / '药智.exe'}")
        print(f"[大小] {((DIST_DIR / '药智.exe').stat().st_size / 1024 / 1024):.2f} MB")
        print()
        print("双击 .exe 即可启动程序（无控制台窗口）")
        print("=" * 60)
    except subprocess.CalledProcessError as e:
        print(f"[ERROR] 打包失败: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()