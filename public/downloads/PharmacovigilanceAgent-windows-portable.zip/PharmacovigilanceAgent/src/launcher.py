"""
PyInstaller 启动器 - 在打包后的 .exe 中运行
负责解压资源并启动浏览器打开 HTML 程序
"""

import os
import sys
import tempfile
import shutil
import time
import subprocess
from pathlib import Path


def get_resource_path(relative_path):
    """获取 PyInstaller 打包后的资源路径"""
    if hasattr(sys, '_MEIPASS'):
        return os.path.join(sys._MEIPASS, relative_path)
    return os.path.join(os.path.dirname(__file__), '..', relative_path)


def find_browser():
    """查找系统中的浏览器"""
    candidates = [
        r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files\Mozilla Firefox\firefox.exe",
        r"C:\Program Files (x86)\Mozilla Firefox\firefox.exe",
    ]
    for path in candidates:
        if os.path.exists(path):
            return path
    return None


def main():
    """主入口 - 解压资源并启动浏览器"""
    work_dir = Path(tempfile.mkdtemp(prefix="pv_agent_"))

    try:
        # 复制资源到临时目录
        resources = [
            "index.html",
            "styles.css",
            "app.js",
            "data/knowledge_base.js",
        ]
        for res in resources:
            src = get_resource_path(res)
            dst = work_dir / res
            dst.parent.mkdir(parents=True, exist_ok=True)
            if os.path.exists(src):
                shutil.copy(src, dst)

        html_path = work_dir / "index.html"

        if not html_path.exists():
            return

        url = f"file:///{html_path.as_posix()}"
        browser = find_browser()

        if browser:
            # 直接启动浏览器，使用start参数打开新窗口
            subprocess.Popen(
                [browser, "--new-window", url],
                creationflags=0
            )
        else:
            # 使用系统默认浏览器
            os.startfile(url)

        # 等待浏览器完全加载
        time.sleep(3)

    except Exception:
        pass


if __name__ == "__main__":
    main()