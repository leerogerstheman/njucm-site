﻿"""
重新生成知识库 JS 文件
用法：将本文件放在 src 目录下，运行 python gen_kb_js.py
"""
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent.parent
JSON_PATH = PROJECT_ROOT / "data" / "knowledge_base.json"
JS_PATH = PROJECT_ROOT / "data" / "knowledge_base.js"

def main():
    print(f"读取: {JSON_PATH}")
    if not JSON_PATH.exists():
        print(f"错误: 找不到 {JSON_PATH}")
        return

    with open(JSON_PATH, "r", encoding="utf-8") as f:
        json_content = f.read()

    header = "// Auto-generated from knowledge_base.json\n// Do not edit manually - edit the JSON source instead\nconst KnowledgeBase = "
    js_content = header + json_content + ";"
    with open(JS_PATH, "w", encoding="utf-8") as f:
        f.write(js_content)

    print(f"生成: {JS_PATH} ({len(js_content)} 字节)")
    print("完成！")

if __name__ == "__main__":
    main()
