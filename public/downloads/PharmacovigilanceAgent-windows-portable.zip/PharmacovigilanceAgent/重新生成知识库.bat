﻿@echo off
chcp 65001 >nul
title 重新生成知识库加载文件
echo ============================================
echo 重新生成知识库加载文件
echo ============================================
echo.
echo [说明] 此脚本会重新生成 knowledge_base.js
echo [说明] 当你编辑了 knowledge_base.json 后运行此脚本
echo.

cd /d "%~dp0"
python "%~dp0src\gen_kb_js.py"

echo.
echo 完成！按任意键关闭窗口...
pause >nul
