# 药智 · 药物警戒助手

> **面向药学学生的智能体学习工具**  
> 基于 [Datawhale hello-agents](https://github.com/datawhalechina/hello-agents) 框架构建  
> UI 遵循 [Material Design 3](https://m3.material.io/) 设计规范

## 项目简介

药智·药物警戒助手是一款面向药学学生的离线智能体工具，帮助学生快速学习药物警戒（Pharmacovigilance）相关知识、法规、术语和实操技能。本项目展示了如何基于 hello-agents 框架的思路，结合 RAG（检索增强生成）技术，构建一个**完全离线、零依赖**的领域智能体应用。

## 快速开始

### 方法一：双击启动（推荐 ✅ 零依赖）

1. **解压项目**：将 `PharmacovigilanceAgent` 文件夹解压到任意位置
2. **双击启动**：双击 `启动药物警戒助手.vbs`（无黑色窗口）或 `启动药物警戒助手.bat`
3. **等待启动**：浏览器将自动打开程序界面

> ⚠️ 无需安装 Python、pip、SQL 或任何其他依赖！  
> 💡 第一次使用建议双击 `.vbs` 文件，体验更流畅。

### 方法二：从命令行启动

```bash
# Windows
双击 "启动药物警戒助手.vbs"
```

## 系统要求

- Windows 7 / 10 / 11 或 macOS / Linux
- 任意现代浏览器（Edge / Chrome / Firefox / Safari）
- **无需** Python / Node.js / 数据库 / 网络连接

## 项目结构

```
PharmacovigilanceAgent/
├── 药智·药物警戒助手.exe       ← ⭐ 主启动器（双击即用，5+ MB）
├── 启动药物警戒助手.vbs         ← 备选启动器（无窗口）
├── 启动药物警戒助手.bat         ← 备选启动器（带说明）
├── index.html                   ← 主程序入口
├── styles.css                   ← Material Design 3 样式
├── app.js                       ← Agent 应用层
├── api.js                       ← ⭐ 统一 API 接口层
├── data/
│   ├── knowledge_base.json      ← 知识库源文件（可编辑，110 KB）
│   └── knowledge_base.js        ← 知识库加载文件（自动生成）
├── src/
│   ├── backend_api.py           ← ⭐ Flask HTTP API 服务（可选）
│   ├── gen_kb_js.py             ← JSON→JS 转换工具
│   ├── launcher.py              ← .exe 启动器逻辑
│   └── build_exe.py             ← PyInstaller 打包脚本
├── API文档.md                   ← ⭐ API 接口文档
└── README.md                    ← 项目文档（本文件）
```

## 功能模块

### 🎓 核心功能

| 模块 | 说明 |
|------|------|
| **智能问答** | 基于 RAG 技术的对话式问答，从知识库检索最相关内容 |
| **知识浏览** | 13 大主题分类、34+ 结构化文档 |
| **Naranjo评分** | 因果关系评价计算器（含 10 项评估） |
| **WHO-UMC评分** | 6级分类评价法 |
| **药物相互作用查询** | 10+ 高风险相互作用数据库 |
| **MedDRA速查** | 常用术语快速检索 |
| **经典案例** | 反应停、万络、文迪雅等历史事件 |
| **API接口** | 双层 API（前端 JS + 后端 Flask） |

### 📚 知识库内容（13 大类，34+ 文档）

1. **基础概念**：药物警戒、ADR、SAE、信号、SUSAR
2. **器官系统ADR**：肝毒性、肾毒性、心脏毒性、皮肤、血液
3. **特殊人群**：妊娠期、老年人、儿童
4. **各论药物ADR**：抗菌药、抗肿瘤药、精神药物
5. **法规与监管机构**：中国GVP、ICH、FDA、EMA、PMDA、NMPA等
6. **报告与流程**：ADR报告、ICSR、PSUR/PBRER
7. **术语与编码**：MedDRA、ATC
8. **药物相互作用**：DDI基础、严重相互作用
9. **经典案例**：反应停、万络、文迪雅
10. **PV工具与技能**：Naranjo、WHO-UMC
11. **风险管理**：RMP
12. **药物基因组学**：CYP450基因多态性、HLA-B等
13. **疫苗警戒**：AEFI

### 📡 API 接口（双层架构）

前端 JavaScript API（`api.js`）提供：
- `api.categories` - 分类管理
- `api.documents` - 文档管理
- `api.query` - 智能问答
- `api.naranjo` - 因果关系评价
- `api.interactions` - 相互作用查询
- `api.meddra` - MedDRA 速查
- `api.cases` - 经典案例
- `api.stats` - 知识库统计

后端 HTTP API（`backend_api.py`）：
- 完整 RESTful 接口
- 端口：5000
- 见 `API文档.md`

## 设计原则

### 1. 用户友好（药学学生专属）
- 大字体、清晰按钮
- 一键访问所有功能
- 离线运行，无需配置
- 中文界面，专业术语精准

### 2. Material Design 3 设计
- 圆角、阴影、动效
- 配色柔和（医疗主题蓝绿色系）
- 暗色模式支持
- 响应式布局

### 3. 类 hello-agents 框架设计
- **SimpleAgent** 模式：单 Agent + 多工具
- **RAG 增强**：意图识别 + 文档检索 + 答案生成
- **工具系统**：Naranjo 计算、相互作用查询、MedDRA 检索

### 4. 完全离线
- 知识库内置
- 无需任何外部 API
- 用户数据 100% 私有

## 使用场景

- 🎓 药学院校教学辅助
- 📖 药剂师、医师继续教育
- 🔍 临床用药决策参考
- 📝 ADR 报告写作助手
- 💊 药物警戒入门自学

## 进阶：编译为单一 .exe 文件

如果您希望将本程序打包为单个 .exe 文件（方便分发），可以运行：

```bash
# 1. 安装 Python（仅开发者需要）
# 2. 运行打包脚本
cd src
python build_exe.py
```

打包脚本会使用 PyInstaller 生成单一可执行文件。

## 常见问题

**Q1：为什么选择 .vbs 作为启动器？**  
A：.vbs 文件在所有 Windows 系统自带支持，双击即可执行，无需任何额外安装。它会调用系统默认浏览器打开程序，体验与 .exe 完全相同。

**Q2：知识库如何更新？**  
A：编辑 `data/knowledge_base.json` 文件，重新生成 `knowledge_base.js`（或将 JSON 内容嵌入 JS）。详见 `docs/知识库更新指南.md`。

**Q3：可以添加自定义知识吗？**  
A：可以！编辑 `data/knowledge_base.json`，在 `categories` 数组中添加新文档即可。

**Q4：可以离线使用吗？**  
A：完全离线，所有数据都内置在项目中。

## 致谢

- [Datawhale hello-agents](https://github.com/datawhalechina/hello-agents) - 智能体构建框架与设计思路
- [ICH](https://www.ich.org/) - 国际化技术标准
- [NMPA](https://www.nmpa.gov.cn/) - 国家药品监督管理局
- [Wikipedia](https://en.wikipedia.org/wiki/Pharmacovigilance) - 基础知识参考
- [MedDRA MSSO](https://www.meddra.org/) - 医学术语集
- [Material Design 3](https://m3.material.io/) - UI 设计规范

## 许可证

本项目仅供学习使用，参考的法规、指南等内容版权归原始机构所有。

---

💡 **提示**：第一次打开后，建议点击右上角的 ❓ 帮助按钮查看使用提示。