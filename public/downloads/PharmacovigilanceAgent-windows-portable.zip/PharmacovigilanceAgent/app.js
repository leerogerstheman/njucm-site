/* ================================================
   药智·药物警戒助手 - 主应用
   基于 hello-agents 框架的 ReAct / RAG 范式
   使用统一的 PVApi 接口层
   ================================================ */

// ================================================
// 全局状态
// ================================================
const State = {
  knowledgeBase: null,
  api: null,         // 新的 API 实例
  conversationHistory: [],
  currentTopic: null,
  theme: 'light',
  useBackend: false, // 是否使用后端 API
  backendUrl: 'http://localhost:5000',
};

// ================================================
// PharmacovigilanceAgent - Agent 核心（保留兼容）
// 类似 hello-agents 的 SimpleAgent
// ================================================
class PharmacovigilanceAgent {
  constructor(knowledgeBase) {
    this.knowledgeBase = knowledgeBase;
  }

  processQuery(query) {
    const intent = this.recognizeIntent(query);

    if (intent.type === 'greeting') return this.handleGreeting();
    if (intent.type === 'tool_naranjo') return this.handleNaranjoHint();
    if (intent.type === 'tool_interaction') return this.handleInteractionHint();

    return this.handleGeneralQuery(query);
  }

  recognizeIntent(query) {
    const q = query.toLowerCase().trim();
    if (/^(你好|hi|hello|您好|嗨)/i.test(q)) return { type: 'greeting' };
    if (/naranjo|评分|因果关系评价/.test(q)) return { type: 'tool_naranjo' };
    if (/相互作用|配伍|联合用药/.test(q)) return { type: 'tool_interaction' };
    return { type: 'general' };
  }

  handleGreeting() {
    return `
      <p>您好！我是药智·药物警戒助手 🤖</p>
      <p>我可以帮您解答：</p>
      <ul>
        <li><strong>基础知识：</strong>药物警戒、ADR、SAE、信号、信号检测</li>
        <li><strong>器官系统ADR：</strong>肝毒性、肾毒性、心脏毒性、皮肤反应等</li>
        <li><strong>特殊人群：</strong>妊娠、老年、儿童用药</li>
        <li><strong>各论药物：</strong>抗菌药、抗肿瘤药、精神药物</li>
        <li><strong>法规指南：</strong>GVP、ICH指南、监管机构</li>
        <li><strong>报告与编码：</strong>ICSR、PSUR、MedDRA、ATC</li>
        <li><strong>经典案例：</strong>反应停、万络、文迪雅</li>
        <li><strong>前沿话题：</strong>药物基因组学、疫苗警戒</li>
      </ul>
      <p>请告诉我您想了解什么？</p>
    `;
  }

  handleNaranjoHint() {
    return `
      <h3>Naranjo 因果关系评价</h3>
      <p>Naranjo 评分法是评价药物与不良反应之间因果关系的标准化工具（1981年）。</p>
      <p>请使用左侧工具栏的"📐 Naranjo评分"按钮进行评估。</p>
      <p><strong>评分标准：</strong></p>
      <ul>
        <li><strong>肯定（Certain）：</strong>≥9分</li>
        <li><strong>很可能（Probable）：</strong>5-8分</li>
        <li><strong>可能（Possible）：</strong>1-4分</li>
        <li><strong>可疑（Doubtful）：</strong>≤0分</li>
      </ul>
    `;
  }

  handleInteractionHint() {
    return `<h3>药物相互作用查询</h3><p>请使用左侧工具栏的"🔄 相互作用查询"按钮查询。</p>`;
  }

  handleGeneralQuery(query) {
    // RAG 检索
    const allDocs = [];
    for (const cat of this.knowledgeBase.categories) {
      for (const doc of cat.documents) {
        allDocs.push({ doc, category: cat, score: this.scoreDocument(query, doc) });
      }
    }

    allDocs.sort((a, b) => b.score - a.score);
    const top = allDocs.filter(d => d.score > 0).slice(0, 2);

    if (top.length === 0) {
      return `<p>${this.knowledgeBase.system_prompts.no_match_response}</p>`;
    }

    let html = '';
    top.forEach(({ doc, category }) => {
      html += `<p style="color: var(--md-sys-color-on-surface-variant); font-size: 12px; margin-top: 12px;">分类：${category.name}</p>`;
      html += this.formatDocument(doc, true);
    });
    return html;
  }

  scoreDocument(query, doc) {
    let score = 0;
    const q = query.toLowerCase();

    if (q.includes(doc.title.toLowerCase()) || doc.title.toLowerCase().includes(q)) score += 10;

    for (const kw of doc.keywords || []) {
      if (q.includes(kw.toLowerCase()) || kw.toLowerCase().includes(q)) score += 3;
    }

    const content = doc.content.toLowerCase();
    for (const token of q.split(/\s+/)) {
      if (token.length >= 2 && content.includes(token)) score += 1;
    }
    return score;
  }

  formatDocument(doc, includeRelated) {
    let html = `<h3>${doc.title}</h3>`;
    let content = doc.content;
    content = content.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    content = content.replace(/【(.+?)】/g, '</p><h3>$1</h3><p>');
    content = content.replace(/\n\n/g, '</p><p>');
    content = content.replace(/\n/g, '<br>');
    html += `<div class="doc-content">${content}</div>`;

    if (includeRelated) {
      html += `<div style="margin-top: 12px;">
        <button class="related-btn" data-doc-id="${doc.id}">
          <span class="material-symbols-outlined">visibility</span> 查看完整内容
        </button>
      </div>`;
    }
    return html;
  }
}

// ================================================
// UI 渲染层
// ================================================
const UI = {
  chatContainer: null,
  userInput: null,
  sendBtn: null,
  sidebarNav: null,
  snackbar: null,

  init() {
    this.chatContainer = document.getElementById('chatContainer');
    this.userInput = document.getElementById('userInput');
    this.sendBtn = document.getElementById('sendBtn');
    this.sidebarNav = document.getElementById('sidebarNav');
    this.snackbar = document.getElementById('snackbar');

    this.bindEvents();
    this.renderSidebar();
  },

  bindEvents() {
    // 发送按钮
    this.sendBtn.addEventListener('click', () => this.handleSend());
    this.userInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        this.handleSend();
      }
    });

    // 自动调整输入框高度
    this.userInput.addEventListener('input', () => {
      this.userInput.style.height = 'auto';
      this.userInput.style.height = Math.min(this.userInput.scrollHeight, 120) + 'px';
    });

    // 建议 chips
    document.querySelectorAll('.chip').forEach(chip => {
      chip.addEventListener('click', () => {
        this.userInput.value = chip.dataset.query;
        this.handleSend();
      });
    });

    // 工具按钮
    document.getElementById('naranjoBtn').addEventListener('click', () => openModal('naranjoModal'));
    document.getElementById('interactionBtn').addEventListener('click', () => openModal('interactionModal'));
    document.getElementById('meddraBtn').addEventListener('click', () => openModal('meddraModal'));
    document.getElementById('caseStudyBtn').addEventListener('click', () => openModal('caseStudyModal'));

    // 帮助按钮
    document.getElementById('helpBtn').addEventListener('click', () => openModal('helpModal'));

    // 主题切换
    document.getElementById('themeBtn').addEventListener('click', () => this.toggleTheme());

    // 关闭模态框
    document.querySelectorAll('.modal-close').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const modal = e.currentTarget.closest('.modal');
        closeModal(modal.id);
      });
    });
    document.querySelectorAll('.modal-backdrop').forEach(backdrop => {
      backdrop.addEventListener('click', (e) => {
        const modal = e.currentTarget.closest('.modal');
        closeModal(modal.id);
      });
    });

    // 相关文档按钮
    document.addEventListener('click', (e) => {
      if (e.target.classList && e.target.classList.contains('related-btn')) {
        const docId = e.target.dataset.docId;
        this.showFullDoc(docId);
      }
    });
  },

  renderSidebar() {
    if (!State.knowledgeBase) return;

    let html = '';
    State.knowledgeBase.categories.forEach(category => {
      const icon = this.getCategoryIcon(category.icon);
      html += `
        <div class="nav-item" data-category-id="${category.id}">
          <span class="material-symbols-outlined">${icon}</span>
          <span>${category.name}</span>
          <span class="nav-item-count">${category.documents.length}</span>
        </div>
      `;
    });

    this.sidebarNav.innerHTML = html;

    document.querySelectorAll('.nav-item[data-category-id]').forEach(item => {
      item.addEventListener('click', () => {
        this.showCategoryDetail(item.dataset.categoryId);
      });
    });
  },

  getCategoryIcon(iconName) {
    const iconMap = {
      'book': 'menu_book',
      'gavel': 'gavel',
      'edit': 'edit_note',
      'library_books': 'library_books',
      'compare_arrows': 'compare_arrows',
      'history_edu': 'history_edu',
      'build': 'build',
      'shield': 'shield',
      'health_and_safety': 'health_and_safety',
      'group': 'group',
      'medication': 'medication',
      'science': 'science',
      'vaccines': 'vaccines'
    };
    return iconMap[iconName] || 'folder';
  },

  async handleSend() {
    const query = this.userInput.value.trim();
    if (!query) return;

    this.appendMessage('user', query);
    this.userInput.value = '';
    this.userInput.style.height = 'auto';

    this.showTyping();

    try {
      // 使用 API 接口层调用
      const result = await State.api.query.ask(query);
      this.hideTyping();
      this.appendMessage('bot', result.response);
    } catch (err) {
      this.hideTyping();
      this.appendMessage('bot', '<p style="color: var(--md-sys-color-error);">处理失败：' + err.message + '</p>');
    }
  },

  appendMessage(type, content) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${type}`;

    const avatar = type === 'user'
      ? '<span class="material-symbols-outlined">person</span>'
      : '<span class="material-symbols-outlined">medical_services</span>';

    messageDiv.innerHTML = `
      <div class="message-avatar">${avatar}</div>
      <div class="message-content">${content}</div>
    `;

    this.chatContainer.appendChild(messageDiv);
    this.scrollToBottom();
    State.conversationHistory.push({ type, content, timestamp: Date.now() });
  },

  showTyping() {
    const typingDiv = document.createElement('div');
    typingDiv.className = 'message bot';
    typingDiv.id = 'typingMessage';
    typingDiv.innerHTML = `
      <div class="message-avatar">
        <span class="material-symbols-outlined">medical_services</span>
      </div>
      <div class="message-content">
        <div class="loading-dots">
          <span></span><span></span><span></span>
        </div>
      </div>
    `;
    this.chatContainer.appendChild(typingDiv);
    this.scrollToBottom();
  },

  hideTyping() {
    const typingDiv = document.getElementById('typingMessage');
    if (typingDiv) typingDiv.remove();
  },

  scrollToBottom() {
    setTimeout(() => {
      this.chatContainer.scrollTop = this.chatContainer.scrollHeight;
    }, 50);
  },

  showCategoryDetail(categoryId) {
    const cat = State.api.categories.summary(categoryId);
    if (!cat) return;

    State.currentTopic = cat;

    document.getElementById('topicModalTitle').textContent = `${cat.name}（${cat.name_en}）`;

    let content = '';
    cat.documents.forEach(doc => {
      content += `
        <div class="topic-doc">
          <h3 class="topic-doc-title">${doc.title}</h3>
          <div class="topic-doc-content">${this.formatContent(doc.preview || doc.title)}</div>
        </div>
      `;
    });

    document.getElementById('topicModalContent').innerHTML = content || '<p>暂无内容</p>';
    openModal('topicModal');
  },

  showFullDoc(docId) {
    const doc = State.api.documents.get(docId);
    if (!doc) return;

    document.getElementById('topicModalTitle').textContent = doc.title;

    let content = `
      <div class="topic-doc">
        <p style="color: var(--md-sys-color-on-surface-variant); font-size: 12px; margin-bottom: 12px;">
          分类：${doc.category_name}（${doc.category}）
        </p>
        <div class="topic-doc-content">${this.formatContent(doc.content)}</div>
    `;

    if (doc.examples && doc.examples.length > 0) {
      content += `<h3 style="margin-top: 16px;">📝 示例</h3>`;
      doc.examples.forEach(ex => {
        content += `<div style="background: var(--md-sys-color-surface-container); padding: 12px; border-radius: 8px; margin: 8px 0; font-size: 13px;">${ex.replace(/\n/g, '<br>')}</div>`;
      });
    }

    if (doc.references && doc.references.length > 0) {
      content += `<h3 style="margin-top: 16px;">📚 参考</h3>`;
      content += `<ul style="font-size: 13px;">`;
      doc.references.forEach(ref => {
        content += `<li>${ref}</li>`;
      });
      content += `</ul>`;
    }

    content += `</div>`;

    document.getElementById('topicModalContent').innerHTML = content;
    openModal('topicModal');
  },

  formatContent(content) {
    let html = content.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    html = html.replace(/【(.+?)】/g, '</p><h3>$1</h3><p>');
    html = html.replace(/\n\n/g, '</p><p>');
    html = html.replace(/\n/g, '<br>');
    html = '<p>' + html + '</p>';
    html = html.replace(/<p><\/p>/g, '');
    return html;
  },

  toggleTheme() {
    const newTheme = State.theme === 'light' ? 'dark' : 'light';
    State.theme = newTheme;
    document.documentElement.setAttribute('data-theme', newTheme);
    this.showSnark(`已切换到${newTheme === 'light' ? '明亮' : '深色'}主题`, 'light_mode');
  },

  showSnark(text, icon = 'check') {
    this.snackbar.innerHTML = `
      <span class="material-symbols-outlined">${icon}</span>
      <span>${text}</span>
    `;
    this.snackbar.classList.add('show');
    setTimeout(() => {
      this.snackbar.classList.remove('show');
    }, 2000);
  },

  showApiStats() {
    const stats = State.api.stats.summary();
    return `
      <h3>📊 知识库统计</h3>
      <div class="kv" style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-top: 12px;">
        <div class="stat-card">
          <div class="stat-value">${stats.documents_count}</div>
          <div class="stat-label">文档总数</div>
        </div>
        <div class="stat-card">
          <div class="stat-value">${stats.categories_count}</div>
          <div class="stat-label">分类数量</div>
        </div>
        <div class="stat-card">
          <div class="stat-value">${stats.interactions_count}</div>
          <div class="stat-label">相互作用记录</div>
        </div>
        <div class="stat-card">
          <div class="stat-value">${stats.cases_count}</div>
          <div class="stat-label">经典案例</div>
        </div>
      </div>
      <p style="margin-top: 12px; color: var(--md-sys-color-on-surface-variant); font-size: 12px;">
        知识库版本: ${stats.version} | 更新日期: ${stats.last_updated}
      </p>
    `;
  }
};

// ================================================
// 模态框管理
// ================================================
function openModal(modalId) {
  document.getElementById(modalId).classList.add('active');
}

function closeModal(modalId) {
  document.getElementById(modalId).classList.remove('active');
}

// ================================================
// Naranjo 评分工具 - 使用 API
// ================================================
const NaranjoTool = {
  init() {
    const questions = State.api.naranjo.questions();
    const container = document.getElementById('naranjoQuestions');

    container.innerHTML = questions.map((q, i) => `
      <div class="naranjo-question">
        <div class="naranjo-question-text">${i + 1}. ${q.text}</div>
        <div class="naranjo-options">
          <button class="naranjo-option" data-q="${q.id}" data-v="yes">是 (+${q.yes})</button>
          <button class="naranjo-option" data-q="${q.id}" data-v="no">否 (${q.no})</button>
          <button class="naranjo-option" data-q="${q.id}" data-v="unknown">不详 (0)</button>
        </div>
      </div>
    `).join('');

    container.querySelectorAll('.naranjo-option').forEach(btn => {
      btn.addEventListener('click', () => {
        const q = btn.dataset.q;
        container.querySelectorAll(`[data-q="${q}"]`).forEach(b => b.classList.remove('selected'));
        btn.classList.add('selected');
      });
    });

    document.getElementById('naranjoCalc').onclick = () => this.calculate();
    document.getElementById('naranjoReset').onclick = () => this.reset();
  },

  calculate() {
    const questions = State.api.naranjo.questions();
    const answers = {};
    questions.forEach(q => {
      const selected = document.querySelector(`[data-q="${q.id}"].selected`);
      if (selected) answers[q.id] = selected.dataset.v;
    });

    if (Object.keys(answers).length < 10) {
      UI.showSnark(`请回答所有问题（已完成 ${Object.keys(answers).length}/10）`, 'info');
      return;
    }

    const result = State.api.naranjo.calculate(answers);

    let bgColor;
    if (result.score >= 9) bgColor = 'var(--md-sys-color-primary-container)';
    else if (result.score >= 5) bgColor = 'var(--md-sys-color-tertiary-container)';
    else if (result.score >= 1) bgColor = 'var(--md-sys-color-secondary-container)';
    else bgColor = 'var(--md-sys-color-error-container)';

    const resultDiv = document.getElementById('naranjoResult');
    resultDiv.style.display = 'block';
    resultDiv.style.background = bgColor;
    resultDiv.innerHTML = `
      <div class="naranjo-result-score">总分：${result.score}</div>
      <div class="naranjo-result-category">${result.category}</div>
      <div class="naranjo-result-desc">${result.description}</div>
    `;
  },

  reset() {
    document.querySelectorAll('.naranjo-option.selected').forEach(b => b.classList.remove('selected'));
    document.getElementById('naranjoResult').style.display = 'none';
  }
};

// ================================================
// 药物相互作用工具 - 使用 API
// ================================================
const InteractionTool = {
  init() {
    document.getElementById('interactionCheckBtn').addEventListener('click', () => this.check());
    document.getElementById('drugA').addEventListener('keydown', (e) => { if (e.key === 'Enter') this.check(); });
    document.getElementById('drugB').addEventListener('keydown', (e) => { if (e.key === 'Enter') this.check(); });
    this.renderKnownInteractions();
  },

  renderKnownInteractions() {
    const list = document.getElementById('interactionList');
    const pairs = State.api.interactions.list();
    list.innerHTML = pairs.map((p, i) => `
      <div class="interaction-item" data-idx="${i}">
        <div class="interaction-item-title">${p.drug_a} + ${p.drug_b}</div>
        <div class="interaction-item-desc">
          严重程度：<strong>${p.severity}</strong> · ${p.consequence}
        </div>
      </div>
    `).join('');

    list.querySelectorAll('.interaction-item').forEach(item => {
      item.addEventListener('click', () => {
        const idx = item.dataset.idx;
        const p = pairs[idx];
        document.getElementById('drugA').value = p.drug_a;
        document.getElementById('drugB').value = p.drug_b;
        this.check();
      });
    });
  },

  check() {
    const a = document.getElementById('drugA').value.trim();
    const b = document.getElementById('drugB').value.trim();
    const result = State.api.interactions.check(a, b);
    const resultDiv = document.getElementById('interactionResult');

    if (result.found) {
      const severityClass = result.severity === '禁忌' || result.severity === '严重' ? 'major'
        : result.severity === '中等' ? 'moderate' : 'minor';

      resultDiv.classList.add('has-data');
      resultDiv.innerHTML = `
        <h4>${result.drug_a} + ${result.drug_b}</h4>
        <span class="severity ${severityClass}">${result.severity}</span>
        <p><strong>作用机制：</strong>${result.mechanism}</p>
        <p><strong>可能后果：</strong>${result.consequence}</p>
        <p><strong>处理建议：</strong>${result.management}</p>
      `;
    } else {
      resultDiv.classList.add('has-data');
      resultDiv.innerHTML = `
        <h4>${a} + ${b}</h4>
        <p style="color: var(--md-sys-color-on-surface-variant);">
          ${result.message}
        </p>
      `;
    }
  }
};

// ================================================
// MedDRA 速查工具 - 使用 API
// ================================================
const MedDRATool = {
  init() {
    const search = document.getElementById('meddraSearch');
    search.addEventListener('input', () => this.render(search.value));
    this.render('');
  },

  render(query) {
    const container = document.getElementById('meddraResults');
    const results = State.api.meddra.search(query);
    const q = (query || '').toLowerCase().trim();

    let html = '';

    if (results.length > 0) {
      results.forEach(({ category, terms }) => {
        html += `
          <div class="meddra-category">
            <div class="meddra-category-title">${category}（${terms.length}）</div>
            <div class="meddra-list">
              ${terms.map(it => `
                <div class="meddra-item">
                  <span class="meddra-cn">${it.cn}</span>
                  <span class="meddra-en">${it.en}</span>
                </div>
              `).join('')}
            </div>
          </div>
        `;
      });
    } else if (q) {
      // 显示全部
      const allData = State.api.meddra.all();
      for (const [catName, items] of Object.entries(allData)) {
        const filtered = items.filter(it =>
          it.cn.toLowerCase().includes(q) || it.en.toLowerCase().includes(q)
        );
        if (filtered.length > 0) {
          html += `
            <div class="meddra-category">
              <div class="meddra-category-title">${catName}（${filtered.length}）</div>
              <div class="meddra-list">
                ${filtered.map(it => `
                  <div class="meddra-item">
                    <span class="meddra-cn">${it.cn}</span>
                    <span class="meddra-en">${it.en}</span>
                  </div>
                `).join('')}
              </div>
            </div>
          `;
        }
      }
    } else {
      // 默认显示全部
      const allData = State.api.meddra.all();
      for (const [catName, items] of Object.entries(allData)) {
        html += `
          <div class="meddra-category">
            <div class="meddra-category-title">${catName}（${items.length}）</div>
            <div class="meddra-list">
              ${items.map(it => `
                <div class="meddra-item">
                  <span class="meddra-cn">${it.cn}</span>
                  <span class="meddra-en">${it.en}</span>
                </div>
              `).join('')}
            </div>
          </div>
        `;
      }
    }

    if (!html) {
      html = `<p style="text-align: center; color: var(--md-sys-color-on-surface-variant); padding: 40px;">未找到匹配的术语</p>`;
    }

    container.innerHTML = html;
  }
};

// ================================================
// 经典案例工具 - 使用 API
// ================================================
const CaseStudyTool = {
  init() {
    const list = document.getElementById('caseStudyList');
    const cases = State.api.cases.list();

    list.innerHTML = cases.map(c => `
      <div class="case-card" data-doc-id="${c.id}">
        <div class="case-card-title">
          <span class="material-symbols-outlined">history_edu</span>
          <span>${c.title}</span>
        </div>
        <div class="case-card-desc">${c.preview}</div>
      </div>
    `).join('');

    list.querySelectorAll('.case-card').forEach(card => {
      card.addEventListener('click', () => {
        closeModal('caseStudyModal');
        UI.showFullDoc(card.dataset.docId);
      });
    });
  }
};

// ================================================
// 应用初始化
// ================================================
async function init() {
  try {
    // 加载知识库
    if (typeof KnowledgeBase === 'undefined') {
      throw new Error('知识库未加载');
    }
    State.knowledgeBase = KnowledgeBase;

    // 创建 API 实例
    State.api = new PVApi(KnowledgeBase);
    State.agent = State.api.agent;  // 兼容旧代码

    // 打印统计信息到控制台
    const stats = State.api.stats.summary();
    console.log('=== 药智·药物警戒助手 初始化完成 ===');
    console.log('版本:', stats.version);
    console.log('分类数:', stats.categories_count);
    console.log('文档数:', stats.documents_count);
    console.log('API 端点:', Object.keys(State.api));

    // 初始化 UI
    UI.init();

    // 初始化工具
    NaranjoTool.init();
    InteractionTool.init();
    MedDRATool.init();
    CaseStudyTool.init();

    // 显示统计信息提示
    setTimeout(() => {
      UI.showSnark(`已加载 ${stats.documents_count} 份文档`, 'database');
    }, 1500);

  } catch (err) {
    console.error('初始化失败:', err);
    document.getElementById('chatContainer').innerHTML = `
      <div style="text-align: center; padding: 40px; color: #BA1A1A;">
        <h2>⚠️ 加载失败</h2>
        <p>${err.message}</p>
      </div>
    `;
  }
}

// 启动应用
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}