' 药智·药物警戒助手 - 无窗口启动器
' 双击此文件即可在浏览器中打开程序（无黑色窗口闪烁）

Dim shell, fso
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

' 获取当前脚本所在目录
Dim scriptPath, scriptDir
scriptPath = WScript.ScriptFullName
scriptDir = fso.GetParentFolderName(scriptPath) & "\"

' 检查主文件是否存在
Dim htmlPath
htmlPath = scriptDir & "index.html"

If Not fso.FileExists(htmlPath) Then
    MsgBox "错误：找不到主程序文件 index.html！" & vbCrLf & _
           "请确认您运行的是完整的项目文件夹。" & vbCrLf & vbCrLf & _
           "当前目录：" & scriptDir, vbCritical, "药智·药物警戒助手"
    WScript.Quit 1
End If

' 尝试使用 Microsoft Edge 打开（默认模式）
Dim edgePath, chromePath
edgePath = shell.ExpandEnvironmentStrings("%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe")
chromePath = shell.ExpandEnvironmentStrings("%ProgramFiles%\Google\Chrome\Application\chrome.exe")

If fso.FileExists(edgePath) Then
    shell.Run """" & edgePath & """ ""file:///" & Replace(htmlPath, "\", "/") & """", 0, False
ElseIf fso.FileExists(chromePath) Then
    shell.Run """" & chromePath & """ ""file:///" & Replace(htmlPath, "\", "/") & """", 0, False
Else
    ' 使用默认浏览器
    shell.Run "file:///" & Replace(htmlPath, "\", "/"), 0, False
End If

Set fso = Nothing
Set shell = Nothing