@echo off
rem ===========================================================
rem  PharmaCrawler portable launcher
rem  Keep this file ASCII-only: cmd.exe reads .bat files using
rem  the system ANSI codepage, so non-ASCII here would be garbled.
rem ===========================================================
chcp 65001 >nul
setlocal
cd /d "%~dp0"
title PharmaCrawler

if not exist "PharmaCrawler.exe" (
  echo [ERROR] PharmaCrawler.exe not found next to this script.
  echo         Please extract the WHOLE folder, not just this file.
  pause
  exit /b 1
)

start "" "PharmaCrawler.exe" gui
endlocal
exit /b 0
